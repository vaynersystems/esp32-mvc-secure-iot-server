//var a = 1;;..

function welcome(){
  //alert('Welcome. The time is ' + time());
  var d = new Date();
  var n = d.toTimeString();
  Console.log('Started page at ' + n);
}